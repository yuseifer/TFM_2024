import gym
import numpy as np
import pybullet as p
import pybullet_data
import pybullet_envs
from CustomAnt_Env.resources.antcustom import robot
from CustomAnt_Env.resources.plane import Plane
import math
from CustomAnt_Env.resources.goal import Goal
from CustomAnt_Env.resources.Cil_obs import cil_obstacle
import matplotlib.pyplot as plt

class AntSimpleCustomEnv(gym.GoalEnv):

    metadata = {'render.modes':['human']}

    def __init__(self):
        super(AntSimpleCustomEnv, self).__init__()

        # Espacio de observación: incluye el estado y la

        self.a_low = [-0.6981317400932312, 0.5235987901687622, -0.6981317400932312, -1.7453292608261108,
                      -0.6981317400932312,
                      -1.7453292608261108, -0.6981317400932312, 0.5235987901687622]
        self.a_high = [0.6981317400932312, 1.7453292608261108, 0.6981317400932312, -0.5235987901687622,
                       0.6981317400932312,
                       -0.5235987901687622, 0.6981317400932312, 1.7453292608261108]
        """
        self.observation_space = self.observation_space = spaces.Dict({
            'observation': gym.spaces.box.Box(
            low=np.array([-10, -10, -10, -math.pi, -math.pi, -math.pi, -10, -10,-20, -20, -20, -20],
                         dtype=np.float32),
            high=np.array([10, 10, 10, math.pi, math.pi, math.pi, 10, 10, 20, 20, 20, 20], dtype=np.float32))
        ,  # Estado actual
            'desired_goal': gym.spaces.Box(low=-np.inf, high=np.inf, shape=(2,), dtype=np.float32)  # Meta
        })"""
        self.observation_space = gym.spaces.Dict({
            'observation': gym.spaces.Box(low=-np.inf, high=np.inf, shape=(20,), dtype=np.float32),  # Estado actual
            'desired_goal': gym.spaces.Box(low=-np.inf, high=np.inf, shape=(2,), dtype=np.float32)  # Meta
        })

        #a_low =[-math.pi/2 for _ in range(8)]
        #a_high = [math.pi / 2 for _ in range(8)]
        self.action_space = gym.spaces.box.Box(
            low=np.array(self.a_low, dtype=np.float32),
            high=np.array(self.a_high, dtype=np.float32))

        self.np_random, _ = gym.utils.seeding.np_random()
        self.type_connection = p.DIRECT
        self.client = p.connect(self.type_connection)
        # Reduce length of episodes for RL algorithms
        p.setTimeStep(1 / 240, self.client)

        self.prev_angles = None
        self.obstacles = []
        self.robot = None
        self.goal = None
        self.done = False
        self.prev_dist = None
        self.rendered_img = None
        self.render_rot_matrix = None
        #Declaramos una variable para cuando se voltee
        self.total_dist = None
        self.limitTimesteps=10000
        self.currentTimesteps=0
        self.prev_dist_to_goal=None
        self.orientation = None
        self.prev_dist_to_obstacles = None
        self.obstacles_r = None
        self.reset()



    def step(self, action):
        self.robot.apply_action(action)
        self.currentTimesteps += 1
        p.stepSimulation()
        robot_ob = self.robot.get_observation()


        p.resetDebugVisualizerCamera(cameraDistance=3, cameraYaw=0, cameraPitch=-40,
                                    cameraTargetPosition=[robot_ob[0],robot_ob[1],robot_ob[2]])
        """
        #Obtenemos la distancia a la meta
        dist_to_goal = math.sqrt(((self.goal[0]-robot_ob[0]) ** 2 +
                                  (self.goal[1]-robot_ob[1]) ** 2))
        #Obtenemos el costo de control en función de la distancia que se avanzó, si retrocedió penaliza y si avanzó recompensa
        ctrl_cost = np.sum(np.abs(np.array(action) - np.array(self.prev_angles))) * (
                    self.prev_dist_to_goal - dist_to_goal)
        #Normalizamos la distancia
        distance_penalty = 0
        n_dist_to_goal = (self.total_dist - dist_to_goal)/self.total_dist
        #Si la distancia a la meta aumentó, se penaliza
        if dist_to_goal >= self.prev_dist_to_goal:
            distance_penalty = 0.2
        #reward_dist = max(0,n_dist_to_goal)
        #Aplicamos escalamiento y clippeo de la recompensa
        reward_dist = max(0, np.clip(n_dist_to_goal*12,0,1))
        self.prev_dist_to_goal = dist_to_goal
        #Añadimos condición de tiempo
        if(self.currentTimesteps > self.limitTimesteps):
            self.done = True
            self.currentTimesteps = 0
        #Condición de fuera de límites
        if math.sqrt(((robot_ob[0]) ** 2 + (robot_ob[1]) ** 2)) > 10:
            self.done = True

        if dist_to_goal < 1:
            self.done = True
            reward_dist +=10000

        orientation_actual = math.atan2((self.goal[1] - robot_ob[1]),(self.goal[0] - robot_ob[0]))
        angle_z = robot_ob[5]
        orientation_actual = orientation_actual-angle_z
        # Normalizar el ángulo para que esté entre -pi y pi
        orientation_actual = (orientation_actual + math.pi) % (2 * math.pi) - math.pi
        alignment_penalty = 0

        if abs(orientation_actual) > abs(self.orientation):
            reward_or = 0
            alignment_penalty = 0.3 * (abs(orientation_actual) - abs(self.orientation))
        else:
            reward_or = max(0, 1 - (abs(orientation_actual) / math.pi))
        self.orientation = orientation_actual

        self.prev_angles = action


        reward = 0.65*reward_dist + 0.15*reward_or +  0.2*ctrl_cost - distance_penalty - alignment_penalty
        """

        """
        if(angle_x >= math.pi/20  or  angle_x <= -math.pi/20):
            self.done = True
            self.currentTimesteps = 0
            reward_angle_x = 5e-10
        elif(angle_y >= math.pi/20  or  angle_y <= -math.pi/20):
            self.done = True
            self.currentTimesteps = 0
            reward_angle_y = 5e-10
        """
        """
        if (robot_ob[2]<0.28 or robot_ob[2] > 0.7 ):
            self.done = True
            reward -=100
        """




        #reward = reward/(reward_angle_x*reward_angle_y)
        #reward = reward * (reward_angle_x * reward_angle_y)
        #añadimos el coste por control por acciones muy largas, la constante de control será 0.5
        #ctrl_cost = (np.sum(action**2))**(1/2)f
        #ctrl_cost = 0.5 * (np.sum(action ** 2)) ** (1 / 2)

        #reward = reward - (prev_control_cost - ctrl_cost)
        #reward = reward - ctrl_cost

        # Añadimos recompensa por velocidad
        velo = math.sqrt((robot_ob[6] ** 2) + (robot_ob[7] ** 2)) * 10
        #velo = math.sqrt((robot_ob[6] ** 2) + (robot_ob[7] ** 2))
        #reward = reward / velo
        #reward = reward * velo

        reward = self.compute_reward(robot_ob, action)
        if (self.currentTimesteps > self.limitTimesteps):
            self.done = True
            self.currentTimesteps = 0

        ob = np.array(robot_ob + self.obstacles + tuple(action), dtype=np.float32)

        #info = {"Distance reward": reward_dist, "Orientation reward": reward_or, "Velocity": velo,
                #"Control cost": ctrl_cost}

        return {
                   'observation': ob,
                   'desired_goal': self.goal
               }, reward, self.done, {}


    def compute_reward(self, robot_ob, action):
        # Distancia a la meta
        dist_to_goal = math.sqrt((self.goal[0] - robot_ob[0]) ** 2 + (self.goal[1] - robot_ob[1]) ** 2)

        #n_dist_to_goal = (self.total_dist - dist_to_goal) / self.total_dist
        # Si la distancia a la meta aumentó, se penaliza

        #reward_dist = max(0, n_dist_to_goal)
        dist_reward = max(0, 1 - (dist_to_goal / self.total_dist))

        # Costo de control basado en el cambio de acciones: Penalizar cambios bruscos
        dist_diff = self.prev_dist_to_goal - dist_to_goal  # Diferencia de distancia

        # Si el robot avanza, recompensamos las acciones que ayudaron a acercarse a la meta
        ctrl_cost = np.sum(np.abs(np.array(action) - np.array(self.prev_angles)))



        # Si el robot retrocede, penalizamos
        if dist_diff < 0:
            ctrl_cost *= 1.5  # Si se aleja de la meta, se aumenta la penalización

        # Recompensa por orientación con suavización cosenoidal
        orientation_actual = math.atan2(self.goal[1] - robot_ob[1], self.goal[0] - robot_ob[0])
        angle_z = robot_ob[5]
        orientation_actual = (orientation_actual - angle_z + math.pi) % (
                    2 * math.pi) - math.pi  # Normalizar entre -pi y pi

        reward_or = np.cos(orientation_actual)  # Suaviza la penalización usando el coseno del ángulo
        distance_penalty = 0.2 if dist_to_goal >= self.prev_dist_to_goal else 0

        orientation_penalty = 0
        if abs(orientation_actual) > abs(self.orientation):
            orientation_penalty = 0.2 * (abs(orientation_actual) - abs(self.orientation))

        #Obstáculos
        # Penalización por proximidad a obstáculos
        obstacle_penalty = 0
        for obs in self.obstacles_r:
            dist_to_obstacle = math.sqrt((obs[0] - robot_ob[0]) ** 2 + (obs[1] - robot_ob[1]) ** 2)
            # Penalizar si está demasiado cerca de un obstáculo
            if dist_to_obstacle < 1.0 and dist_to_obstacle>=0.5:  # Umbral de distancia, ajusta según sea necesario
                obstacle_penalty += (1.0 - dist_to_obstacle) ** 2  # Penalización cuadrática
            elif dist_to_obstacle <0.5:
                self.done = True
                obstacle_penalty = 100

        # Actualizamos valores previos
        self.prev_dist_to_goal = dist_to_goal
        self.prev_angles = action
        self.orientation = orientation_actual  # Actualizamos el ángulo de orientación

        # Recompensa total, ajustada para pequeños movimientos
        reward = 0.6 * dist_reward + 0.2 * reward_or - 0.2 * ctrl_cost - distance_penalty - orientation_penalty

        # Penalización si el robot sale de los límites o si la altura es inapropiada
        if robot_ob[2] < 0.28 or robot_ob[2] > 0.7 or math.sqrt(robot_ob[0] ** 2 + robot_ob[1] ** 2) > 10:
            self.done = True
            reward -= 10000

        # Gran recompensa al alcanzar la meta
        if dist_to_goal < 1:
            self.done = True
            reward += 10000

        return reward


    def reset(self):
        self.currentTimesteps = 0
        self.init_angles = np.array([0, 0.523, 0, -0.523, 0, -0.523, 0, 0.523])
        p.resetSimulation(self.client)
        p.setGravity(0, 0, -10)
        # Reload the plane and car
        Plane(self.client)
        self.robot = robot(self.client)
        self.done = False

        # Get observation to return
        robot_ob = self.robot.get_observation()
        # Obtenemos la posición inicial
        self.prev_dist = [robot_ob[0], robot_ob[1]]
        x = (self.np_random.uniform(0.5, 9) if self.np_random.randint(2) else
             self.np_random.uniform(-0.5, -9))
        y = (self.np_random.uniform(0.5, 9) if self.np_random.randint(2) else
             self.np_random.uniform(-0.5, -9))
        self.goal = (x, y)
        Goal(self.client, self.goal)
        self.orientation = math.atan2(y, x) - robot_ob[5]
        self.orientation = (self.orientation + math.pi) % (2 * math.pi) - math.pi
        self.prev_dist_to_goal = math.sqrt(((robot_ob[0] - self.goal[0]) ** 2 +
                                            (robot_ob[1] - self.goal[1]) ** 2))
        self.total_dist = self.prev_dist_to_goal

        self.prev_angles = [0, 0.523, 0, -0.523, 0, -0.523, 0, 0.523]


        #Añado los obstáculos
        obstacles = []
        for i in range(2):
            xo = (self.np_random.uniform(0, 6) if self.np_random.randint(2) else
                  self.np_random.uniform(-6, 0))
            yo = (self.np_random.uniform(0, 6) if self.np_random.randint(2) else
                  self.np_random.uniform(-6, 0))
            # self.obstacles.append((xo, yo))
            obstacles.append((xo, yo))
            cil_obstacle(self.client, (xo, yo))
        self.obstacles_r = (obstacles[0], obstacles[1])
        self.obstacles = (obstacles[0]+obstacles[1])

        return {
                   'observation': np.array(robot_ob + self.obstacles+ tuple(self.prev_angles), dtype=np.float32),
                   'desired_goal': self.goal
               }

    def calcular_penalizacion_suavidad(self,angulos_actuales, angulos_anteriores, joint_limits, penalizacion_brusquedad=0.1,
                                       penalizacion_saturacion=0.1, penalizacion_pequenos=0.1,umbral_pequeno=0.01):
        """
        Calcula un término de penalización basado en la brusquedad de los movimientos
        de las articulaciones y la saturación de los ángulos.

        Parámetros:
        - angulos_actuales: Lista con los ángulos actuales de las articulaciones.
        - angulos_anteriores: Lista con los ángulos de las articulaciones en el paso anterior.
        - joint_limits: Diccionario con los límites mínimos y máximos de las articulaciones.
        - penalizacion_brusquedad: Factor de penalización por cambios bruscos en los ángulos.
        - penalizacion_saturacion: Factor de penalización por alcanzar límites de las articulaciones.

        Retorna:
        - El valor de penalización total.
        """
        # Penalización por cambio brusco en las articulaciones

        dif_angulos = np.abs(np.array(angulos_actuales) - np.array(angulos_anteriores))
        penalizacion_brusca = penalizacion_brusquedad * np.sum(dif_angulos)

        # Penalización por saturación de las articulaciones
        penalizacion_satur = 0
        for i, angulo in enumerate(angulos_actuales):
            if angulo <= joint_limits['min'][i] or angulo >= joint_limits['max'][i]:
                penalizacion_satur += penalizacion_saturacion

        penalizacion_pequena = 0
        for dif in dif_angulos:
            if dif < umbral_pequeno:
                penalizacion_pequena += penalizacion_pequenos

        penalizacion_total = penalizacion_brusca + penalizacion_satur + penalizacion_pequena
        return penalizacion_total

    def render(self, mode='human'):
        if mode == 'human':
            p.disconnect(self.client)
            self.client = p.connect(p.GUI)
            self.reset()
            return None

        elif mode == 'rgb_array':
            # Configurar cámara
            view_matrix = p.computeViewMatrix(
                cameraEyePosition=[3, 3, 2],
                cameraTargetPosition=[0, 0, 0],
                cameraUpVector=[0, 0, 1]
            )
            proj_matrix = p.computeProjectionMatrixFOV(
                fov=60, aspect=1.0, nearVal=0.1, farVal=100.0
            )
            # Obtener imagen
            width, height = 320, 320
            img = p.getCameraImage(width, height, viewMatrix=view_matrix, projectionMatrix=proj_matrix)
            rgb_array = np.reshape(img[2], (height, width, 4))
            return rgb_array[:, :, :3]  # Retornar solo el RGB sin el canal alpha




    def close(self):
        p.disconnect(self.client)

    def seed(self, seed=None):
        self.np_random, seed = gym.utils.seeding.np_random(seed)
        return [seed]


"""Notas de versión
Cambie la función de recompensa
CAMBIADO EL ESPACIO DE ACCIÓN
NUEVA FUNCIÓN DE RECOMPENSA PARA LLEGAR A UNA META
"""