from gym.envs.registration import register

register(
    id='AntCustomEnv-v0',
    entry_point='CustomAnt_Env.envs:AntSimpleCustomEnv'
)