import pybullet as p
import os
import math
import pybullet_envs
import pybullet_data
import numpy as np
import math

class robot:



    def __init__(self,client):
        self.client = client
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        #f_name = os.path.join(os.path.dirname(__file__), 'minitaur.urdf')
        self.startOrientation = p.getQuaternionFromEuler([0, 0, 0])
        self.startPos = [0, 0, 0.36]
        self.joints = [1, 3, 6, 8, 11, 13, 16, 18]
        self.forces = [2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000]
        self.init_angles = [0, 0.523, 0, -0.523, 0, -0.523, 0, 0.523]
        self.m_robot = p.loadMJCF("mjcf/ant.xml",physicsClientId=self.client)
        for obj in self.m_robot:
            p.resetBasePositionAndOrientation(obj, self.startPos, self.startOrientation)
        for j, v in zip(self.joints, self.init_angles):
            p.resetJointState(self.m_robot[0], j, targetValue=v)
        self.angles = [0*x for x in range(len(self.joints))]
    def get_ids(self):
        return self.m_robot,self.client

    def apply_action(self,action):
        a_low = [-0.6981317400932312, 0.5235987901687622, -0.6981317400932312, -1.7453292608261108,
                      -0.6981317400932312,
                      -1.7453292608261108, -0.6981317400932312, 0.5235987901687622]
        a_high = [0.6981317400932312, 1.7453292608261108, 0.6981317400932312, -0.5235987901687622,
                       0.6981317400932312,
                       -0.5235987901687622, 0.6981317400932312, 1.7453292608261108]

        for i in range(len(action)):
            action[i] = np.clip(action[i],a_low[i],a_high[i])



        p.setJointMotorControlArray(self.m_robot[0],
                                    self.joints,
                                    controlMode=p.POSITION_CONTROL,
                                    targetPositions=action,
                                    forces=self.forces,
                                    physicsClientId=self.client
                                    )

    def get_observation(self):
        pos, ang = p.getBasePositionAndOrientation(self.m_robot[0],self.client)
        ang = p.getEulerFromQuaternion(ang)
        #oriYZ = (math.cos(ang[0]), math.sin(ang[0]))
        #oriXZ = (math.cos(ang[1]), math.sin(ang[1]))
        #oriXY = (math.cos(ang[2]), math.sin(ang[2]))
        # Get the velocity of the car
        vel = p.getBaseVelocity(self.m_robot[0], self.client)[0][0:2]

        # Concatenate position, orientation, velocity
        observation = (pos + ang + vel)

        return observation
